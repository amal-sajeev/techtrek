"""Generates a comprehensive PDF report for a single event."""

import io
import os
from collections import Counter, defaultdict
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from sqlalchemy import func
from sqlalchemy.orm import Session as DbSession

# ---------------------------------------------------------------------------
# Font registration (shared pattern with invoice.py)
# ---------------------------------------------------------------------------

_FONT_REGISTERED = False
_FONT_CHECKED = False


def _register_fonts():
    global _FONT_REGISTERED, _FONT_CHECKED
    if _FONT_CHECKED:
        return
    _FONT_CHECKED = True

    font_sets = [
        [("Arial", "C:/Windows/Fonts/arial.ttf"),
         ("Arial-Bold", "C:/Windows/Fonts/arialbd.ttf")],
        [("Arial", "/usr/share/fonts/dejavu-sans-fonts/DejaVuSans.ttf"),
         ("Arial-Bold", "/usr/share/fonts/dejavu-sans-fonts/DejaVuSans-Bold.ttf")],
        [("Arial", "/usr/share/fonts/dejavu/DejaVuSans.ttf"),
         ("Arial-Bold", "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf")],
        [("Arial", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
         ("Arial-Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")],
    ]
    for candidates in font_sets:
        if all(os.path.exists(p) for _, p in candidates):
            for name, path in candidates:
                pdfmetrics.registerFont(TTFont(name, path))
            _FONT_REGISTERED = True
            return


# ---------------------------------------------------------------------------
# Colour palette
# ---------------------------------------------------------------------------

_DARK = colors.HexColor("#0a1628")
_ACCENT = colors.HexColor("#00d4ff")
_MUTED = colors.HexColor("#555555")
_LIGHT_GREY = colors.HexColor("#f5f5f5")
_GRID = colors.HexColor("#cccccc")
_WHITE = colors.white

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_PAGE_W, _PAGE_H = A4
_MARGIN_LR = 20 * mm
_MARGIN_TB = 15 * mm
_CONTENT_W = _PAGE_W - 2 * _MARGIN_LR


def _esc(text) -> str:
    if text is None:
        return ""
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _fmt_currency(val) -> str:
    r = _rupee()
    try:
        return f"{r}{float(val):,.2f}"
    except (TypeError, ValueError):
        return f"{r}0.00"


def _pct(part, total) -> str:
    if not total:
        return "0%"
    return f"{part / total * 100:.1f}%"


# ---------------------------------------------------------------------------
# Table builder helpers
# ---------------------------------------------------------------------------

def _styled_table(data, col_widths=None, *, has_header=True):
    """Return a Table with the project's standard visual style."""
    t = Table(data, colWidths=col_widths, repeatRows=1 if has_header else 0)
    cmds = [
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("LEADING", (0, 0), (-1, -1), 11),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, _GRID),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
    ]
    if has_header:
        cmds += [
            ("BACKGROUND", (0, 0), (-1, 0), _DARK),
            ("TEXTCOLOR", (0, 0), (-1, 0), _WHITE),
            ("FONTNAME", (0, 0), (-1, 0), _font_bold()),
            ("FONTSIZE", (0, 0), (-1, 0), 8),
        ]
    for i in range(1 if has_header else 0, len(data)):
        if i % 2 == 0:
            cmds.append(("BACKGROUND", (0, i), (-1, i), _LIGHT_GREY))
    t.setStyle(TableStyle(cmds))
    return t


def _font():
    return "Arial" if _FONT_REGISTERED else "Helvetica"


def _font_bold():
    return "Arial-Bold" if _FONT_REGISTERED else "Helvetica-Bold"


def _rupee():
    return "Rs."


# ---------------------------------------------------------------------------
# Main generator
# ---------------------------------------------------------------------------

def generate_event_report_pdf(db: DbSession, event_id: int) -> bytes:
    from app.models.booking import Booking
    from app.models.coupon import Coupon
    from app.models.event import Event
    from app.models.event_addon import BookingAddOn, EventAddOn
    from app.models.event_break import EventBreak
    from app.models.event_session import EventSession
    from app.models.feedback import Feedback, SessionRating
    from app.models.feedback_template import FeedbackResponse, QuestionResponse, TemplateQuestion
    from app.models.poll import Poll, PollOption, PollVote
    from app.models.seat import Seat
    from app.models.session import Session
    from app.models.session_feedback import SessionFeedback
    from app.models.user import User
    from app.models.waitlist import Waitlist

    _register_fonts()
    font = _font()
    font_b = _font_bold()
    rupee = _rupee()

    event = db.query(Event).get(event_id)
    if not event:
        raise ValueError(f"Event {event_id} not found")

    # ── Styles ────────────────────────────────────────────────────────────
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("RTitle", fontName=font_b, fontSize=18, textColor=_DARK,
                              spaceAfter=8, alignment=TA_LEFT))
    styles.add(ParagraphStyle("RSub", fontName=font, fontSize=10, textColor=_MUTED,
                              spaceAfter=6))
    styles.add(ParagraphStyle("RSection", fontName=font_b, fontSize=12, textColor=_DARK,
                              spaceBefore=16, spaceAfter=6, keepWithNext=True))
    styles.add(ParagraphStyle("RSubSection", fontName=font_b, fontSize=10, textColor=_DARK,
                              spaceBefore=10, spaceAfter=4, keepWithNext=True))
    styles.add(ParagraphStyle("RBody", fontName=font, fontSize=9, textColor=colors.black,
                              spaceAfter=4))
    styles.add(ParagraphStyle("RSmall", fontName=font, fontSize=8, textColor=_MUTED))
    styles.add(ParagraphStyle("RMetricVal", fontName=font_b, fontSize=16, textColor=_DARK,
                              alignment=TA_CENTER, spaceAfter=1))
    styles.add(ParagraphStyle("RMetricLabel", fontName=font, fontSize=7, textColor=_MUTED,
                              alignment=TA_CENTER))

    elements = []

    # =====================================================================
    # HEADER
    # =====================================================================
    elements.append(Paragraph(_esc(event.name), styles["RTitle"]))
    subtitle_parts = []
    if event.start_date:
        d = event.start_date.strftime("%b %d, %Y")
        if event.end_date and event.end_date != event.start_date:
            d += f" \u2013 {event.end_date.strftime('%b %d, %Y')}"
        subtitle_parts.append(d)
    if event.auditorium:
        venue = event.auditorium.name
        if event.college:
            venue += f", {event.college.name}"
        subtitle_parts.append(venue)
    subtitle_parts.append(f"Status: {(event.status or 'draft').title()}")
    elements.append(Paragraph(" | ".join(subtitle_parts), styles["RSub"]))
    elements.append(Paragraph(
        f"Generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p')}",
        styles["RSmall"],
    ))
    elements.append(Spacer(1, 10))

    # =====================================================================
    # KEY METRICS
    # =====================================================================
    bookings_q = db.query(Booking).filter(
        Booking.event_id == event_id,
        Booking.payment_status == "paid",
        Booking.is_shared_ticket == False,
    )
    total_bookings = bookings_q.count()
    total_revenue = db.query(func.coalesce(func.sum(Booking.amount_paid), 0)).filter(
        Booking.event_id == event_id,
        Booking.payment_status == "paid",
        Booking.is_shared_ticket == False,
    ).scalar()
    checked_in = bookings_q.filter(Booking.checked_in == True).count()
    checkin_pct = _pct(checked_in, total_bookings)
    waitlist_count = db.query(Waitlist).filter(Waitlist.event_id == event_id).count()
    poll_count = db.query(Poll).filter(Poll.event_id == event_id).count()
    feedback_count = db.query(FeedbackResponse).filter(FeedbackResponse.event_id == event_id).count()
    feedback_count += db.query(Feedback).filter(Feedback.event_id == event_id).count()

    metric_data = [
        [
            Paragraph(str(total_bookings), styles["RMetricVal"]),
            Paragraph(f"{rupee}{float(total_revenue):,.0f}", styles["RMetricVal"]),
            Paragraph(checkin_pct, styles["RMetricVal"]),
            Paragraph(str(waitlist_count), styles["RMetricVal"]),
            Paragraph(str(poll_count), styles["RMetricVal"]),
            Paragraph(str(feedback_count), styles["RMetricVal"]),
        ],
        [
            Paragraph("Bookings", styles["RMetricLabel"]),
            Paragraph("Revenue", styles["RMetricLabel"]),
            Paragraph("Check-in Rate", styles["RMetricLabel"]),
            Paragraph("Waitlist", styles["RMetricLabel"]),
            Paragraph("Polls", styles["RMetricLabel"]),
            Paragraph("Feedback", styles["RMetricLabel"]),
        ],
    ]
    col_w = _CONTENT_W / 6
    mt = Table(metric_data, colWidths=[col_w] * 6)
    mt.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("TOPPADDING", (0, 0), (-1, 0), 10),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 2),
        ("BOTTOMPADDING", (0, 1), (-1, 1), 8),
        ("BOX", (0, 0), (-1, -1), 0.5, _GRID),
        ("LINEBELOW", (0, 0), (-1, 0), 0, colors.transparent),
        ("BACKGROUND", (0, 0), (-1, -1), _LIGHT_GREY),
    ]))
    elements.append(KeepTogether([mt]))
    elements.append(Spacer(1, 6))

    # =====================================================================
    # SCHEDULE / AGENDA
    # =====================================================================
    ev_sessions = (
        db.query(EventSession)
        .filter(EventSession.event_id == event_id)
        .order_by(EventSession.order, EventSession.start_time)
        .all()
    )
    ev_breaks = (
        db.query(EventBreak)
        .filter(EventBreak.event_id == event_id)
        .order_by(EventBreak.order, EventBreak.start_time)
        .all()
    )
    agenda_addons = (
        db.query(EventAddOn)
        .filter(EventAddOn.event_id == event_id, EventAddOn.in_agenda == True)
        .order_by(EventAddOn.order)
        .all()
    )

    agenda_items = []
    for es in ev_sessions:
        agenda_items.append({
            "order": es.order or 0,
            "start_time": es.start_time,
            "type": "Session",
            "title": es.session.title if es.session else "—",
            "detail": es.speaker_name or (es.session.speaker_name if es.session else ""),
            "duration": f"{es.session.duration_minutes} min" if es.session and es.session.duration_minutes else "",
        })
    for brk in ev_breaks:
        agenda_items.append({
            "order": brk.order or 0,
            "start_time": brk.start_time,
            "type": "Break",
            "title": brk.title,
            "detail": brk.description or "",
            "duration": f"{brk.duration_minutes} min" if brk.duration_minutes else "",
        })
    for addon in agenda_addons:
        agenda_items.append({
            "order": addon.order or 0,
            "start_time": addon.start_time,
            "type": "Add-On",
            "title": addon.title,
            "detail": addon.description or "",
            "duration": "",
        })
    agenda_items.sort(key=lambda x: (x["order"], x["start_time"] or datetime.min))

    if agenda_items:
        elements.append(Paragraph("Schedule / Agenda", styles["RSection"]))
        rows = [["#", "Time", "Type", "Title", "Speaker / Detail", "Duration"]]
        for i, item in enumerate(agenda_items, 1):
            t_str = item["start_time"].strftime("%b %d, %I:%M %p") if item["start_time"] else ""
            rows.append([
                str(i), t_str, item["type"],
                Paragraph(_esc(item["title"]), styles["RSmall"]),
                Paragraph(_esc(item["detail"]), styles["RSmall"]),
                item["duration"],
            ])
        elements.append(_styled_table(rows, col_widths=[20, 75, 40, 145, 130, 45]))
        elements.append(Spacer(1, 4))

    # =====================================================================
    # FINANCIAL BREAKDOWN
    # =====================================================================
    elements.append(Paragraph("Financial Breakdown", styles["RSection"]))

    # Revenue by seat type
    seat_rev = (
        db.query(Seat.seat_type, func.count(Booking.id), func.sum(Booking.amount_paid))
        .join(Booking, Booking.seat_id == Seat.id)
        .filter(Booking.event_id == event_id, Booking.payment_status == "paid",
                Booking.is_shared_ticket == False)
        .group_by(Seat.seat_type)
        .all()
    )
    if seat_rev:
        elements.append(Paragraph("Revenue by Seat Type", styles["RSubSection"]))
        rows = [["Seat Type", "Tickets", "Revenue"]]
        for stype, cnt, rev in seat_rev:
            display = (stype or "standard").replace("_", " ").title()
            rows.append([display, str(cnt), _fmt_currency(rev)])
        elements.append(_styled_table(rows, col_widths=[200, 80, 175]))
        elements.append(Spacer(1, 4))

    # Coupon usage
    coupons = db.query(Coupon).filter(Coupon.event_id == event_id).all()
    if coupons:
        elements.append(Paragraph("Coupon Usage", styles["RSubSection"]))
        rows = [["Code", "Discount", "Uses", "Max Uses"]]
        for c in coupons:
            disc = f"{c.discount_pct}%" if c.discount_pct else _fmt_currency(c.discount_amount)
            rows.append([c.code, disc, str(c.used_count), str(c.max_uses or "\u221e")])
        elements.append(_styled_table(rows, col_widths=[130, 120, 80, 80]))
        elements.append(Spacer(1, 4))

    # Add-on sales
    all_addons = db.query(EventAddOn).filter(EventAddOn.event_id == event_id).all()
    if all_addons:
        elements.append(Paragraph("Add-On Sales", styles["RSubSection"]))
        rows = [["Add-On", "Price", "Qty Sold", "Revenue"]]
        for addon in all_addons:
            qty = (
                db.query(func.coalesce(func.sum(BookingAddOn.quantity), 0))
                .filter(BookingAddOn.addon_id == addon.id)
                .scalar()
            )
            rev = float(addon.price or 0) * int(qty)
            rows.append([
                Paragraph(_esc(addon.title), styles["RSmall"]),
                _fmt_currency(addon.price), str(qty), _fmt_currency(rev),
            ])
        elements.append(_styled_table(rows, col_widths=[180, 90, 60, 125]))
        elements.append(Spacer(1, 4))

    # =====================================================================
    # BOOKING ANALYSIS
    # =====================================================================
    elements.append(Paragraph("Booking Analysis", styles["RSection"]))

    # By payment status
    status_counts = (
        db.query(Booking.payment_status, func.count(Booking.id))
        .filter(Booking.event_id == event_id, Booking.is_shared_ticket == False)
        .group_by(Booking.payment_status)
        .all()
    )
    if status_counts:
        elements.append(Paragraph("Bookings by Status", styles["RSubSection"]))
        rows = [["Status", "Count"]]
        for status, cnt in status_counts:
            rows.append([(status or "unknown").title(), str(cnt)])
        elements.append(_styled_table(rows, col_widths=[250, 205]))
        elements.append(Spacer(1, 4))

    # Bookings over time
    daily = (
        db.query(func.date_trunc("day", Booking.booked_at).label("d"), func.count(Booking.id))
        .filter(Booking.event_id == event_id, Booking.payment_status == "paid",
                Booking.is_shared_ticket == False)
        .group_by("d")
        .order_by("d")
        .all()
    )
    if daily:
        elements.append(Paragraph("Daily Booking Trend", styles["RSubSection"]))
        rows = [["Date", "Bookings"]]
        for d, cnt in daily:
            d_str = d.strftime("%b %d, %Y") if hasattr(d, "strftime") else str(d)
            rows.append([d_str, str(cnt)])
        elements.append(_styled_table(rows, col_widths=[250, 205]))
        elements.append(Spacer(1, 4))

    # =====================================================================
    # ATTENDEE DEMOGRAPHICS
    # =====================================================================
    booked_user_ids = [
        r[0] for r in
        db.query(Booking.user_id)
        .filter(Booking.event_id == event_id, Booking.payment_status == "paid",
                Booking.is_shared_ticket == False)
        .distinct()
        .all()
    ]

    if booked_user_ids:
        elements.append(Paragraph("Attendee Demographics", styles["RSection"]))
        users = db.query(User).filter(User.id.in_(booked_user_ids)).all()

        # Colleges
        college_counts = Counter(u.college for u in users if u.college).most_common(15)
        if college_counts:
            elements.append(Paragraph("Top Colleges", styles["RSubSection"]))
            rows = [["College", "Attendees"]]
            for name, cnt in college_counts:
                rows.append([Paragraph(_esc(name), styles["RSmall"]), str(cnt)])
            elements.append(_styled_table(rows, col_widths=[350, 105]))
            elements.append(Spacer(1, 4))

        # Discipline
        disc_counts = Counter(u.discipline for u in users if u.discipline).most_common(10)
        if disc_counts:
            elements.append(Paragraph("Discipline Distribution", styles["RSubSection"]))
            rows = [["Discipline", "Count"]]
            for name, cnt in disc_counts:
                rows.append([_esc(name), str(cnt)])
            elements.append(_styled_table(rows, col_widths=[350, 105]))
            elements.append(Spacer(1, 4))

        # Year of study
        year_counts = Counter(u.year_of_study for u in users if u.year_of_study)
        if year_counts:
            elements.append(Paragraph("Year of Study", styles["RSubSection"]))
            rows = [["Year", "Count"]]
            for yr in sorted(year_counts.keys()):
                rows.append([str(yr), str(year_counts[yr])])
            elements.append(_styled_table(rows, col_widths=[350, 105]))
            elements.append(Spacer(1, 4))

    # =====================================================================
    # CHECK-IN STATISTICS
    # =====================================================================
    if total_bookings:
        elements.append(Paragraph("Check-in Statistics", styles["RSection"]))
        not_checked = total_bookings - checked_in
        rows = [["Status", "Count", "Percentage"]]
        rows.append(["Checked In", str(checked_in), _pct(checked_in, total_bookings)])
        rows.append(["Not Checked In", str(not_checked), _pct(not_checked, total_bookings)])
        rows.append(["Total", str(total_bookings), "100%"])
        elements.append(_styled_table(rows, col_widths=[200, 100, 155]))
        elements.append(Spacer(1, 4))

    # =====================================================================
    # WAITLIST
    # =====================================================================
    if waitlist_count:
        elements.append(Paragraph("Waitlist", styles["RSection"]))
        notified = db.query(Waitlist).filter(
            Waitlist.event_id == event_id, Waitlist.notified == True
        ).count()
        waitlist_user_ids = [
            r[0] for r in
            db.query(Waitlist.user_id).filter(Waitlist.event_id == event_id).all()
        ]
        converted = 0
        if waitlist_user_ids:
            converted = db.query(Booking).filter(
                Booking.event_id == event_id,
                Booking.payment_status == "paid",
                Booking.user_id.in_(waitlist_user_ids),
            ).distinct(Booking.user_id).count()
        rows = [["Metric", "Value"]]
        rows.append(["Total on Waitlist", str(waitlist_count)])
        rows.append(["Notified", str(notified)])
        rows.append(["Converted to Booking", str(converted)])
        elements.append(_styled_table(rows, col_widths=[300, 155]))
        elements.append(Spacer(1, 4))

    # =====================================================================
    # POLL RESULTS
    # =====================================================================
    polls = (
        db.query(Poll)
        .filter(Poll.event_id == event_id)
        .order_by(Poll.created_at)
        .all()
    )
    if polls:
        elements.append(Paragraph("Poll Results", styles["RSection"]))
        for poll in polls:
            status_label = "Active" if poll.is_active else "Closed"
            elements.append(Paragraph(
                f"{_esc(poll.question)} <font size='7' color='#888'>({status_label})</font>",
                styles["RSubSection"],
            ))
            options = (
                db.query(PollOption)
                .filter(PollOption.poll_id == poll.id)
                .order_by(PollOption.order)
                .all()
            )
            total_votes = db.query(PollVote).filter(PollVote.poll_id == poll.id).count()

            if poll.poll_type in ("multiple_choice", "single_choice") and options:
                rows = [["Option", "Votes", "Share"]]
                for opt in options:
                    opt_votes = db.query(PollVote).filter(
                        PollVote.poll_id == poll.id, PollVote.option_id == opt.id
                    ).count()
                    rows.append([
                        Paragraph(_esc(opt.option_text), styles["RSmall"]),
                        str(opt_votes),
                        _pct(opt_votes, total_votes),
                    ])
                rows.append(["Total", str(total_votes), ""])
                elements.append(_styled_table(rows, col_widths=[270, 60, 125]))
            elif poll.poll_type == "rating":
                avg = db.query(func.avg(PollVote.rating_value)).filter(
                    PollVote.poll_id == poll.id,
                    PollVote.rating_value.isnot(None),
                ).scalar()
                avg_str = f"{float(avg):.1f}" if avg else "N/A"
                elements.append(Paragraph(
                    f"Average Rating: <b>{avg_str}</b> &nbsp; ({total_votes} responses)",
                    styles["RBody"],
                ))
            else:
                elements.append(Paragraph(f"Responses: {total_votes}", styles["RBody"]))
            elements.append(Spacer(1, 4))

    # =====================================================================
    # FEEDBACK SUMMARY
    # =====================================================================
    fb_responses = db.query(FeedbackResponse).filter(FeedbackResponse.event_id == event_id).all()
    fb_legacy = db.query(Feedback).filter(Feedback.event_id == event_id).all()
    has_feedback = fb_responses or fb_legacy

    if has_feedback:
        elements.append(Paragraph("Feedback Summary", styles["RSection"]))

        all_ratings = []
        for fr in fb_responses:
            if fr.overall_rating:
                all_ratings.append(fr.overall_rating)
        for fl in fb_legacy:
            if fl.rating:
                all_ratings.append(fl.rating)

        if all_ratings:
            avg_rating = sum(all_ratings) / len(all_ratings)
            elements.append(Paragraph(
                f"Average Rating: <b>{avg_rating:.1f}</b> / 5 &nbsp; "
                f"({len(all_ratings)} rating{'s' if len(all_ratings) != 1 else ''})",
                styles["RBody"],
            ))

        # Per-session ratings
        session_ratings = (
            db.query(
                Session.title,
                func.avg(SessionFeedback.rating).label("avg_r"),
                func.count(SessionFeedback.id).label("cnt"),
            )
            .join(SessionFeedback, SessionFeedback.session_id == Session.id)
            .filter(SessionFeedback.event_id == event_id, SessionFeedback.rating.isnot(None))
            .group_by(Session.id, Session.title)
            .all()
        )
        if not session_ratings:
            session_ratings = (
                db.query(
                    Session.title,
                    func.avg(SessionRating.rating).label("avg_r"),
                    func.count(SessionRating.id).label("cnt"),
                )
                .join(SessionRating, SessionRating.session_id == Session.id)
                .join(Feedback, Feedback.id == SessionRating.feedback_id)
                .filter(Feedback.event_id == event_id)
                .group_by(Session.id, Session.title)
                .all()
            )
        if session_ratings:
            elements.append(Paragraph("Per-Session Ratings", styles["RSubSection"]))
            rows = [["Session", "Avg Rating", "Responses"]]
            for title, avg_r, cnt in session_ratings:
                rows.append([
                    Paragraph(_esc(title), styles["RSmall"]),
                    f"{float(avg_r):.1f}" if avg_r else "N/A",
                    str(cnt),
                ])
            elements.append(_styled_table(rows, col_widths=[270, 80, 105]))
            elements.append(Spacer(1, 4))

        # Notable comments (up to 10)
        comments = []
        for fr in fb_responses:
            if fr.comment and fr.comment.strip():
                comments.append(fr.comment.strip())
        for fl in fb_legacy:
            if fl.comment and fl.comment.strip():
                comments.append(fl.comment.strip())
        if comments:
            elements.append(Paragraph("Selected Comments", styles["RSubSection"]))
            for c in comments[:10]:
                elements.append(Paragraph(
                    f"\u2022 {_esc(c[:300])}{'...' if len(c) > 300 else ''}",
                    styles["RSmall"],
                ))
            if len(comments) > 10:
                elements.append(Paragraph(
                    f"<i>...and {len(comments) - 10} more</i>", styles["RSmall"],
                ))
            elements.append(Spacer(1, 4))

    # =====================================================================
    # ATTENDEE ROSTER
    # =====================================================================
    roster = (
        db.query(Booking, User, Seat)
        .join(User, User.id == Booking.user_id)
        .join(Seat, Seat.id == Booking.seat_id)
        .filter(
            Booking.event_id == event_id,
            Booking.payment_status == "paid",
            Booking.is_shared_ticket == False,
        )
        .order_by(User.full_name, User.username)
        .all()
    )
    if roster:
        elements.append(Paragraph("Attendee Roster", styles["RSection"]))
        rows = [["#", "Name", "Email", "Ref", "Seat", "Paid", "Checked In"]]
        for i, (bk, usr, seat) in enumerate(roster, 1):
            name = usr.full_name or usr.username or "—"
            email = usr.email or "—"
            rows.append([
                str(i),
                Paragraph(_esc(name), styles["RSmall"]),
                Paragraph(_esc(email), styles["RSmall"]),
                bk.booking_ref or "",
                seat.label or "",
                _fmt_currency(bk.amount_paid),
                "Yes" if bk.checked_in else "No",
            ])
        elements.append(_styled_table(
            rows, col_widths=[22, 100, 115, 55, 40, 65, 58],
        ))

    # =====================================================================
    # BUILD PDF
    # =====================================================================
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=_MARGIN_LR, rightMargin=_MARGIN_LR,
        topMargin=_MARGIN_TB, bottomMargin=_MARGIN_TB,
    )

    event_name = event.name

    def _footer(canvas, doc_obj):
        canvas.saveState()
        canvas.setFont(font, 7)
        canvas.setFillColor(_MUTED)
        canvas.drawString(_MARGIN_LR, 10 * mm,
                          f"{event_name} \u2014 Event Report")
        canvas.drawRightString(
            _PAGE_W - _MARGIN_LR, 10 * mm,
            f"Page {doc_obj.page}",
        )
        canvas.restoreState()

    doc.build(elements, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()
