import io
import base64
import uuid
from datetime import datetime, timedelta, timezone

import qrcode
from sqlalchemy.orm import Session

from app.config import settings
from app.models.booking import Booking, _generate_ticket_id
from app.models.seat import Seat
from app.models.session import LectureSession
from app.models.user import User
from app.services.email import send_booking_confirmation

CANCELLATION_FEE = 100.0
TICKET_PRICE = 500.0


def get_seat_map(db: Session, session_id: int, auditorium_id: int):
    seats = (
        db.query(Seat)
        .filter(Seat.auditorium_id == auditorium_id, Seat.is_active == True)
        .order_by(Seat.row_num, Seat.col_num)
        .all()
    )
    now = datetime.now(timezone.utc)
    booked_seat_ids = set(
        sid
        for (sid,) in db.query(Booking.seat_id)
        .filter(
            Booking.session_id == session_id,
            (Booking.payment_status == "paid")
            | (
                (Booking.payment_status == "hold")
                & (Booking.held_until > now)
            ),
        )
        .all()
    )

    seat_map = []
    for seat in seats:
        status = "available"
        if seat.seat_type == "aisle":
            status = "aisle"
        elif seat.id in booked_seat_ids:
            status = "taken"
        seat_map.append(
            {
                "id": seat.id,
                "row": seat.row_num,
                "col": seat.col_num,
                "label": seat.label,
                "type": seat.seat_type,
                "status": status,
            }
        )
    return seat_map


def hold_seats(
    db: Session, user_id: int, session_id: int, seat_ids: list[int]
) -> list[Booking]:
    now = datetime.now(timezone.utc)
    held_until = now + timedelta(minutes=settings.hold_timeout_minutes)

    cancel_existing_holds(db, user_id, session_id)

    bookings = []
    for seat_id in seat_ids:
        existing = (
            db.query(Booking)
            .filter(
                Booking.seat_id == seat_id,
                Booking.session_id == session_id,
                (Booking.payment_status == "paid")
                | (
                    (Booking.payment_status == "hold")
                    & (Booking.held_until > now)
                ),
            )
            .first()
        )
        if existing:
            continue

        booking = Booking(
            user_id=user_id,
            session_id=session_id,
            seat_id=seat_id,
            payment_status="hold",
            booking_ref=uuid.uuid4().hex[:10].upper(),
            held_until=held_until,
        )
        db.add(booking)
        bookings.append(booking)

    db.commit()
    for b in bookings:
        db.refresh(b)
    return bookings


def _generate_qr_base64(data: str) -> str:
    qr = qrcode.QRCode(version=1, box_size=6, border=2)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


def confirm_payment(db: Session, user_id: int, session_id: int) -> list[Booking]:
    now = datetime.now(timezone.utc)
    lecture = db.query(LectureSession).get(session_id)
    price = float(lecture.price) if lecture else TICKET_PRICE

    holds = (
        db.query(Booking)
        .filter(
            Booking.user_id == user_id,
            Booking.session_id == session_id,
            Booking.payment_status == "hold",
            Booking.held_until > now,
        )
        .all()
    )
    for b in holds:
        b.payment_status = "paid"
        b.booked_at = now
        b.held_until = None
        b.amount_paid = price
        b.ticket_id = _generate_ticket_id()
        b.qr_code_data = _generate_qr_base64(b.ticket_id)
    db.commit()

    if holds:
        user = db.query(User).get(holds[0].user_id)
        for b in holds:
            seat = db.query(Seat).get(b.seat_id)
            if user and seat:
                send_booking_confirmation(
                    user.email, user.username,
                    lecture.title if lecture else "Session",
                    seat.label, b.ticket_id, b.booking_ref,
                )

    return holds


def cancel_booking_user(db: Session, booking_id: int, user_id: int) -> dict:
    b = db.query(Booking).filter(Booking.id == booking_id, Booking.user_id == user_id).first()
    if not b or b.payment_status != "paid":
        return {"ok": False, "msg": "Booking not found or already cancelled."}

    lecture = db.query(LectureSession).get(b.session_id)
    price = b.amount_paid or float(lecture.price) if lecture else TICKET_PRICE
    fee = CANCELLATION_FEE
    refund = max(0, price - fee)

    b.payment_status = "refunded"
    b.cancellation_fee = fee
    b.refund_amount = refund
    db.commit()
    return {"ok": True, "msg": f"Booking cancelled. Refund of ₹{refund:.0f} will be processed (₹{fee:.0f} cancellation fee).", "refund": refund, "fee": fee}


def cancel_existing_holds(db: Session, user_id: int, session_id: int):
    holds = (
        db.query(Booking)
        .filter(
            Booking.user_id == user_id,
            Booking.session_id == session_id,
            Booking.payment_status == "hold",
        )
        .all()
    )
    for h in holds:
        h.payment_status = "cancelled"
    db.commit()


def get_user_bookings(db: Session, user_id: int):
    return (
        db.query(Booking)
        .filter(Booking.user_id == user_id, Booking.payment_status.in_(["paid", "refunded"]))
        .order_by(Booking.booked_at.desc())
        .all()
    )
